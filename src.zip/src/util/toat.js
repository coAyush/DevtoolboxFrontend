import toast from "react-hot-toast"

export const toastSuccess = (message) => {
    return toast.success(message)
}
export const toastError = (message) => {
    return toast.error(message)
}
export const toastLoading = (message) => {
    return toast.loading(message)
}
export const toastCustom = (message) => {
    return toast(message, {
        style: {
            background: "#000",
            color: "#fff",
        },
    })
}