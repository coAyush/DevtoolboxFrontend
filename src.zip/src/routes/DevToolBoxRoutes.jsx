import { createBrowserRouter, RouterProvider } from "react-router";

import AppLayout from "../layout/AppLayout";

import Landing from "../pages/landing/Landing";
import Features from "../pages/landing/feature/Features";
import Pricing from "../pages/landing/Pricing";

import Loading from "../pages/Loading";
import Signup from "../pages/Signup";
import Login from "../pages/Login";
import ForgotPassword from "../pages/ForgotPassword";
import Tools from "../pages/landing/Tools";
import AboutUs from "../pages/landing/AboutUs";

export const router = createBrowserRouter([
    {
        element: <AppLayout />,
        children: [
            {
                path: "/",
                element: <Landing />,
            },
            {
                path: "features",
                element: <Features />,
                loader: async () => {
                    await new Promise((resolve) => setTimeout(resolve, 500));
                    return null;
                }
            },
            {
                path: "pricing",
                element: <Pricing />,
                loader: async () => {
                    await new Promise((resolve) => setTimeout(resolve, 500));
                    return null;
                }
            },
            {
                path: "tools",
                element: <Tools />,
                loader: async () => {
                    await new Promise((resolve) => setTimeout(resolve, 500));
                    return null;
                }
            },
            {
                path: "aboutUs",
                element: <AboutUs />
            }
        ]
    },
    {
        path: "/signup",
        element: <Signup />
    },

    {
        path: "/login",
        element: <Login />
    },

    {
        path: "/password-reset",
        element: <ForgotPassword />
    }
]);

const DevToolBoxRoutes = () => {
    return (
        <RouterProvider
            router={router}
            fallbackElement={<Loading />}
        />
    );
};

export default DevToolBoxRoutes;