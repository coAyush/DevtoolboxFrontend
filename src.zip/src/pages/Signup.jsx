import React from 'react'
import PageBackground from '../styles/Pagebackground'
import Terminal from '../styles/Terminal'
import SignupContainer from '../components/signup/SignupContainer'

const Signup = () => {
  return (
    <div className="overflow-hidden min-h-screen w-full flex items-center justify-center">
      <PageBackground>
        <Terminal className="h-[92vh] max-h-[880px] w-[94vw] max-w-6xl items-center justify-center p-2 sm:p-4 z-10 relative">
          <SignupContainer desc="Select your workspace type to personalize your experience" />
        </Terminal>
      </PageBackground>
    </div>
  )
}

export default Signup
