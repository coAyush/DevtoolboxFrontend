import { useEffect, useState } from "react";
import PageBackground from "../styles/Pagebackground";
import EmailEnter from "../components/forgot_password/EmailEnter";
import VerifyOtp from "../components/forgot_password/VerifyOtp";
import ResetPassword from "../components/forgot_password/ResetPassword";
import { toastLoading, toastSuccess } from "../util/toat";

const ForgotPassword = () => {
  const [step, setStep] = useState(1);
  useEffect(() => {
    toastLoading("Submitted")
  }, [step])
  return (
    <>
      <PageBackground>
        <div className="w-full h-screen flex flex-col items-center justify-center gap-y-4">
          {
            step == 1 && <EmailEnter step={step} setStep={setStep} />
          }
          {
            step === 2 && <> <EmailEnter step={step} setStep={setStep} />
              <VerifyOtp setStep={setStep} />
            </>
          }
          {
            step === 3 && <ResetPassword step={step} setStep={setStep} />
          }
        </div>
      </PageBackground>
    </>
  )
}
export default ForgotPassword;