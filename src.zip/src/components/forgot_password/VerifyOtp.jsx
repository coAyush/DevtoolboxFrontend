import { useRef, useState } from "react";
import LoadingSpinner from "../../util/LoadingSpinner";

const VerifyOtp = ({ setStep }) => {
    const [otp, setOtp] = useState(["", "", "", "", "", ""]);
    const [isLoading, setIsLoading] = useState(false);

    const inputRef = useRef([]);

    const handleChange = (event, index) => {
        const value = event.target.value;

        if (!/^\d?$/.test(value)) {
            return;
        }

        const newOtp = [...otp];
        newOtp[index] = value;

        setOtp(newOtp);

        if (value && index < 5) {
            inputRef.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (event, index) => {

        if (
            event.key === "Backspace" &&
            !otp[index] &&
            index > 0
        ) {
            inputRef.current[index - 1]?.focus();
        }
    };

    const sendData = () => {
        setIsLoading(true);

        const otpValue = otp.join("");

        console.log("OTP:", otpValue);

        setTimeout(() => {
            setIsLoading(false);
            setStep(3);
        }, 3000);
    };

    return (
        <div className="relative w-[90%] sm:w-[75%] md:w-[60%] lg:w-[45%]
                        p-[1px] rounded-2xl overflow-hidden">

            {/* Gradient border */}
            <div className="absolute inset-0
                            bg-[linear-gradient(90deg,#06b6d4,#8b5cf6,#ec4899,#06b6d4)]
                            bg-[length:300%_100%]
                            animate-border-flow" />

            <div className="relative rounded-2xl
                            bg-slate-950/90
                            backdrop-blur-xl
                            px-6 py-6
                            flex flex-col gap-6">

                {/* Header */}
                <div className="flex items-center justify-between">

                    <span className="text-xs font-semibold tracking-[0.2em] text-cyan-400">
                        STEP 2 OF 3
                    </span>

                    <span className="text-xs text-slate-500">
                        Verification
                    </span>

                </div>

                <div>
                    <h2 className="text-2xl font-bold text-white">
                        Verify your email
                    </h2>

                    <p className="mt-1 text-sm text-slate-400">
                        Enter the 6-digit verification code sent to your email.
                    </p>
                </div>

                {/* OTP boxes */}
                <div className="flex justify-center gap-2 sm:gap-3">

                    {otp.map((value, index) => (
                        <input
                            key={index}
                            value={value}
                            ref={(element) => {
                                inputRef.current[index] = element;
                            }}
                            onChange={(event) =>
                                handleChange(event, index)
                            }
                            onKeyDown={(event) =>
                                handleKeyDown(event, index)
                            }
                            inputMode="numeric"
                            type="text"
                            maxLength={1}
                            className="
                                w-10 h-12
                                sm:w-12 sm:h-14
                                text-center
                                text-lg sm:text-xl
                                font-bold
                                text-white
                                bg-slate-900/70
                                border border-slate-700
                                rounded-xl
                                outline-none

                                focus:border-cyan-400
                                focus:ring-2
                                focus:ring-cyan-400/20

                                transition-all duration-200
                            "
                        />
                    ))}

                </div>

                {/* Verify button */}
                <button
                    className="
                        relative
                        w-full h-12
                        rounded-xl

                        bg-gradient-to-r
                        from-cyan-500
                        via-purple-500
                        to-pink-500

                        hover:brightness-110
                        active:scale-[0.99]

                        transition-all duration-200

                        flex items-center justify-center

                        disabled:opacity-60
                        disabled:cursor-not-allowed
                    "
                    onClick={sendData}
                    disabled={isLoading || otp.join("").length !== 6}
                >

                    {isLoading ? (
                        <LoadingSpinner
                            color="white"
                            loading={true}
                            size={25}
                        />
                    ) : (
                        <span className="font-semibold text-white">
                            Verify Code
                        </span>
                    )}

                </button>

            </div>
        </div>
    );
};

export default VerifyOtp;